package main

import "github.com/kleriston/net-monitor-log-kleriston/cmd"

func main() {
	cmd.Execute()
}
