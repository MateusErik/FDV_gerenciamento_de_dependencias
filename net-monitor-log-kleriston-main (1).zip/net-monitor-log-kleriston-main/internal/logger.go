package internal

// Aqui será implementado o logger com logrus.
// Pode deixar esse arquivo como esqueleto, caso Matheus vá integrar depois.
